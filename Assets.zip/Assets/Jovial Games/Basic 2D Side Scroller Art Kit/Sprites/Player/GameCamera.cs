using UnityEngine;

public class GameCamera : MonoBehaviour
{
    private Transform target;

    public float offsetY = 3f;
    public float smoothSpeed = 8f;

    void Start()
    {
        target = GameObject.FindGameObjectWithTag("Player").transform;
    }

    void LateUpdate()
    {
        Vector3 targetPosition = new Vector3(
            transform.position.x,
            target.position.y + offsetY,
            transform.position.z
        );

        transform.position = Vector3.Lerp(
            transform.position,
            targetPosition,
            Time.deltaTime * smoothSpeed
        );
    }
}