
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Tilemaps;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour
{
    public float flyForce = 5f;
    public float moveSpeed = 5f;

    private Rigidbody2D rb;
    private Animator animator;

    public Image staminabar;

    public float Stamina, MaxStamina;
    public float AttackCost;
    public float ChargeRate;

    public bool isDead = false;

    private AudioSource audioSource;
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        audioSource = GetComponent<AudioSource>();

        Application.targetFrameRate = 60;
        QualitySettings.vSyncCount = 0;
    }

    void Update()
    {
        // Stop player controls when dead or game is paused
        if (isDead || Time.timeScale == 0)
            return;

        // Jump / Fly
        if ((Input.GetKeyDown(KeyCode.Space) ||
            Input.GetMouseButtonDown(0)) && Stamina >= AttackCost)
        {
            audioSource.Play();
            rb.linearVelocity = new Vector2(
                rb.linearVelocity.x, flyForce);

            Debug.Log("Attack");

            Stamina -= AttackCost;

            if (Stamina < 0)
                Stamina = 0;

            staminabar.fillAmount = Stamina / MaxStamina;
        }

        // Stamina recharge
        if (Stamina < MaxStamina)
        {
            Stamina += ChargeRate * Time.deltaTime;

            if (Stamina > MaxStamina)
                Stamina = MaxStamina;

            staminabar.fillAmount = Stamina / MaxStamina;
        }

        // Horizontal movement
        float horizontal = Input.GetAxisRaw("Horizontal");

        rb.linearVelocity = new Vector2(
            horizontal * moveSpeed,
            rb.linearVelocity.y
        );

        // Animations
        if (horizontal < 0)
        {
            animator.SetBool("FlyingLeft", true);
        }
        else
        {
            animator.SetBool("FlyingLeft", false);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Tilemap"))
        {
            GameOver();
        }
    }

    private void GameOver()
    {
        if (isDead)
            return;

        isDead = true;

        rb.linearVelocity = Vector2.zero;
        rb.simulated = false;
    }

    int coins = 0;

    public void AddCoin()
    {
        coins++;
    }
}