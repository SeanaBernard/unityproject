using UnityEngine;

public class MoveTileMapLeft : MonoBehaviour
{
    public float speed = 2f;
    private Vector3 startPosition; //this means the tile map starts at the beginning

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        startPosition = transform.position; 
    }
    // Update is called once per frame
    public float stopX = -100f;

    void Update()
    {
        if (transform.position.x > stopX)
        {
            transform.position += Vector3.left * speed * Time.deltaTime;
        }
    }
}
